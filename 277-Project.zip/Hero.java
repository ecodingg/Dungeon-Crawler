import java.awt.*;
public class Hero extends Entity implements Fighter,Archer,Magical{
  private Point loc;
  private int level;
  private int gold;
  private int keys;
  private int potions;

  /**
  *Constructor for the Hero object
  *@param the name of the hero
  *@param the HP of the hero, max and starting
  */
  public Hero( String n, int mHp ) {
    super( n, mHp );
    level = 1;
    loc = Map.getInstance().findStart();
  }

  /**
  *A function that returns the hero's current level
  *@return the current level of the hero
  */
  public int getLevel(){
    return level;
  }

  /**
  *A function that levels up the player
  */
  public void levelUp(){
    level++;
  }

  /**
  *A function that tries to move the character north, and returns the map's room there
  *@return represents the type of room the hero entered, or x if it's out of bounds
  */
  public char goNorth(){
    if ( loc.getY() == 0 ){
      return 'x';
    }
    loc.translate( 0,-1 );
    Map.getInstance().reveal( loc );
    return Map.getInstance().getCharAtLoc( loc );
  }

  /**
  *A function that tries to move the character south, and returns the map's room there
  *@return represents the type of room the hero entered, or x if it's out of bounds
  */
  public char goSouth(){
    if ( loc.getY() == 4 ){
      return 'x';
    }
    loc.translate( 0,1 );
    Map.getInstance().reveal( loc );
    return Map.getInstance().getCharAtLoc( loc );
  }

  /**
  *A function that tries to move the character east, and returns the map's room there
  *@return represents the type of room the hero entered, or x if it's out of bounds
  */
  public char goEast(){
    if ( loc.getX() == 4 ){
      return 'x';
    }
    loc.translate( 1,0 );
    Map.getInstance().reveal( loc );
    return Map.getInstance().getCharAtLoc( loc );
  }

  /**
  *A function that tries to move the character west, and returns the map's room there
  *@return represents the type of room the hero entered, or x if it's out of bounds
  */
  public char goWest(){
    if ( loc.getX() == 0 ){
      return 'x';
    }
    loc.translate( -1,0 );
    Map.getInstance().reveal( loc );
    return Map.getInstance().getCharAtLoc( loc );
  }

  /**
  *A function that returns the string with the hero's combat options
  *@return the hero's combat options
  */
  public String getAttackMenu(){
    return "1. Physical Attack\n2. Magical Attack\n3. Ranged Attack";
  }

  /**
  *A function that gets
  *@return
  */
  public int getNumAttackMenuItems(){
    int choice = CheckInput.getIntRange( 1,3 );
    return choice;
  }
  /**
  *Method that displays attack options
  *@return the menu string
  */
  public String getSubAttackMenu( int choice ){
    String subMenu = "";
    if ( choice == 1 ){
      subMenu = "1. Sword\n2. Axe";
    }
    if ( choice == 2 ){
      subMenu = "1. Magic Missile\n2. Fireball";
    }
    if ( choice == 3 ){
      subMenu = "1. Arrow\n2. Fire Arrow";
    }
    return subMenu;
  }
  /**
  *Method gets the desired input for attack
  *@return in representing attack
  */
  public int getNumSubAttackMenuItems( int choice ){
    int subChoice = CheckInput.getInt();
    return subChoice;
  }
  /**
  *Method specifies an attack
  *@return string representing the attack done
  */
  @Override
  public String arrow( Entity e ) {
    int damage = (int)( Math.random()*3 )+1;
    e.takeDamage( damage );
    return super.getName()+" shoots "+e.getName()+" with an arrow for " + damage;
  }
  /**
  *Method specifies an attack
  *@return string representing the attack done
  */
  @Override
  public String fireArrow( Entity e ) {
    //determine damage
    int damage = (int)( Math.random()*5 )+1;
    e.takeDamage( damage );
    return super.getName()+" shoots "+e.getName()+" with a fire arrow for "+damage;
  }
  /**
  *Method specifies an attack
  *@return string representing the attack done
  */
  @Override
  public String sword( Entity e ) {
    //determine damage
    int damage = (int)( Math.random()*4 )+1;
    e.takeDamage( damage );
    return super.getName()+" slashes "+e.getName()+" with a sword for "+damage;
  }
  /**
  *Method specifies an attack
  *@return string representing the attack done
  */
  @Override
  public String axe( Entity e ) {
    //determine damage
    int damage = (int)( Math.random()*5 )+1;
    e.takeDamage( damage );
    return super.getName()+" hacks "+e.getName()+" with an axe for "+damage;
  }
  /**
  *Method specifies an attack
  *@return string representing the attack done
  */
  @Override
  public String magicMissile( Entity e ) {
    //determine damage
    int damage = (int)( Math.random()*3 )+1;
    e.takeDamage( damage );
    return super.getName()+" fires "+e.getName()+" with a magic missile for "+damage;
  }
  /**
  *Method specifies an attack
  *@return string representing the attack done
  */
  @Override
  public String fireBall( Entity e ) {
    //determine damage
    int damage = (int)( Math.random()*6 )+1;
    e.takeDamage( damage );
    return super.getName()+" fires "+e.getName()+" with a fireball for "+damage;
  }
  /**
  *Method that is the actual action of an attack
  *@return string displaying the attack done
  */
  public String attack( Enemy e,int choice, int subChoice ){
    if ( choice == 1 && subChoice == 1 ){
      return sword( e );
    }
    if ( choice == 1 && subChoice == 2 ){
      return axe( e );
    }
    if ( choice == 2 && subChoice == 1 ){
      return magicMissile( e );
    }
    if ( choice == 2 && subChoice == 2 ){
      return fireBall( e );
    }
    if ( choice == 3 && subChoice == 1 ){
      return arrow( e );
    }
    if ( choice == 3 && subChoice == 2 ){
      return fireArrow( e );
    }
    return "";
  }
  /**
  *function gets gold
  *@return int number of gold
  */
  public int getGold(){
    return gold;
  }
  /**
  *function collects gold
  *@param amount to be added
  */
  public void collectGold( int g ){
    gold += g;
  }
  /**
  *function used to spend gold
  *@param amount of gold to be used
  */
  public boolean spendGold( int g ){
    gold -= g;
    return true;
  }
  /**
  *function returns true if the player has one or more keys
  *@return the result of the if statement
  */
  public boolean hasKey(){
    if ( keys >= 1 ){
      return true;
    }
    return false;
  }
  /**
  *Method collects a key
  */
  public void pickUpKey(){
    keys++;
  }
  /**
  *Method uses a key and reduces the number of keys collected
  *@return a boolean if there are still keys in the inventory
  */
  public boolean useKey(){
    if ( keys >= 1 ){
      keys-=1;
      return true;
    }
    return false;
  }
  /**
  *function returns true if there is at least one potion in the inventory
  *@return true if there is one or more potions else returns false
  */
  public boolean hasPotion(){
    if ( potions >= 1 ){
      return true;
    }
    return false;
  }
  /**
  *function collects potions
  */
  public void pickUpPotion(){
    potions++;
  }
  /**
  *function uses a potion and heals the hero to full
  *@return true if the action is completed under the conditions else return false
  */
  public boolean usePotion(){
    if ( potions >= 1 ){
      this.heal();
      potions-=1;
      return true;
    }
    return false;
  }
  /**
  *function returns a point of current location of the hero
  *@return point of current location
  */
  public Point getLoc(){
    return loc;
  }
  /**
  *function outputs the key info about the hero
  *@return string representing the level, gold, potions, keys, and the location on the current map
  */
  @Override
  public String toString(){
    return super.toString() + "\nLevel: " + level + "\nGold: " + gold + "\nP: " + potions + " K: " + keys + '\n' + Map.getInstance().mapToString( loc );
  }
}
