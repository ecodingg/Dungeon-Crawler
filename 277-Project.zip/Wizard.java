import java.util.*;
/**
*One of the enemy architypes, implements the Magical interface
*/
public class Wizard extends Enemy implements Magical{
  /**
  *The Wizard constructor
  *@param The name of the Entity
  *@param The maximum health of the Entity
  *@return The super constructor of the Entity
  */
  public Wizard( String name, int maxHP ){
    super( name, maxHP );
  }

  /**
  *The magic missile attack
  *Returns the string for the attack
  *@param The entity using the magic missile Attack
  *@return A string response of the magic missile attack
  */
  @Override
  public String magicMissile( Entity e ) {
    int attackDamage = (int)( Math.random()*4+2 );
    e.takeDamage( attackDamage );
    return super.getName() + " fires " + e.getName() + " with a magic missile for " + attackDamage;
    }

  /**
  *The fire ball attack
  *Returns the string for the attack
  *@param The entity using the fire ball Attack
  *@return A string response of the fire ball attack
  */
  @Override
  public String fireBall( Entity e ) {
    int attackDamage = (int)( Math.random()*6+1 );
    e.takeDamage( attackDamage );
    return super.getName() + " fire " + e.getName() + " with a fireball for " + attackDamage;
  }

  /**
  *The attack function
  *ranAttack randomly selects a number between 1 and 2 and then the function determines which attack to do based on the number
  *@param The hero that the player uses  
  *@return The attack chosen
  */
  @Override
  public String attack( Hero h ) {
    int ranAttack = (int)( Math.random()*2+1 );
    if ( ranAttack == 1 ){
      return this.magicMissile( h );
    }
    if ( ranAttack == 2 ){
       return this.fireBall( h );
    }
  return null;
  }
}
