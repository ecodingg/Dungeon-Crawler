/**
 * 277 Project
 * By Ethan Doss-Fillmore, Ben Gupton, and Tristan Jackson
 */

public class Main {
  public static void main( String[] args ) {
    EnemyGenerator enemyFactory = new EnemyGenerator();
    System.out.println( "What is your name, traveler? " );
    String name = CheckInput.getString();
    System.out.println( "Welcome, " + name + " to the dungeon crawler. Below are your stats:" );
    int mapNum = 1;
    Map map = Map.getInstance();
    map.loadMap( mapNum );
    //map.toString(); DEBUG
    Hero h = new Hero( name, 25 );
    boolean heroAlive = true;
    boolean mapLoaded = false;
    while ( heroAlive ) {
      int heroLevel = h.getLevel();
      if ( heroLevel == 4 ){
        System.out.println( "You win!" );
        heroAlive = false;
        System.exit( 0 );
      }
      int heroHp = h.getHp();
      if ( heroHp == 0 ) {
        System.out.println( "You died!" );
        heroAlive = false;
        System.exit( 0 );
      }
      System.out.println( h.toString() );
      char tile = ' ';
      switch ( mainMenu(h) ){
        case 1:
          tile = h.goNorth();
          break;
        case 2:
          tile = h.goSouth();
          break;
        case 3:
          tile = h.goEast();
          break;
        case 4:
          tile = h.goWest();
          break;
        case 5:
          System.out.println( "Thank you for playing!" );
          heroAlive = false;
          break;
      }
      if ( !heroAlive ) {
        //Exit loop early
        break;
      }
      switch ( tile ) {
        case 'x':
          System.out.println( "Location was out of bounds" );
          break;
        case 'n':
          System.out.println( "There was nothing here" );
          break;
        case 's':
          store( h );
          break;
        case 'f':
          if ( h.hasKey() ) {
            h.levelUp();
            h.useKey();
            mapNum++;
            if ( mapNum > 3 ){
              mapNum = 1;
            }
            map.loadMap( mapNum );
          }
          break;
        case 'i':
          int ranItem = (int)( Math.random()*2-1+1 )+1;
          if ( ranItem == 1 ){
            h.pickUpKey();
            System.out.println( "You found a key!" );
          } else if ( ranItem == 2 ){
            h.pickUpPotion();
            System.out.println( "You found a potion!" );
          }
          map.removeCharAtLoc( h.getLoc() );
          break;
        case 'm':
          Enemy e = enemyFactory.generateEnemy( h.getLevel() );
          if ( !monsterRoom( h, e ) ){
            //If the hero kills the monster, remove it from the map
            map.removeCharAtLoc( h.getLoc() );
          }
          break;
      }
    }
  }
  /**
  *Monster Room function where it handles combat with an enemy and a hero
  *@param The Hero representing the player
  *@param The enemy the hero is facing
  *@return true when the enemy is still alive
  */
  public static boolean monsterRoom( Hero h, Enemy e ) {
    boolean EnemyAlive = true;
    System.out.println( "You have encountered a " + e.getName() );
    while ( h.getHp() > 0 && EnemyAlive) {
      e.toString();
      System.out.println( "1. Fight\n2. Run Away" );
      if ( h.hasPotion() ) {
        System.out.println( "3. Drink Potion" );
        int potionMenuInput = CheckInput.getIntRange( 1, 3 );
        if ( potionMenuInput == 1 ) {
          EnemyAlive = fight( h,e );
        }
        if ( potionMenuInput == 2 ) {
          int ranDirec = (int)( Math.random()*4 )+1;
          switch( ranDirec ){
            case 1:
              char result = h.goNorth();
              if ( result == 'x' ){
                h.goSouth();
              }
              break;
            case 2:
              result = h.goSouth();
              if ( result == 'x' ){
                h.goNorth();
              }
              break;
            case 3:
              result = h.goEast();
              if ( result == 'x' ){
                h.goWest();
              }
              break;
            case 4:
              result = h.goWest();
              if ( result == 'x' ){
                h.goEast();
              }
              break;
          }
          return EnemyAlive;
        }
        if ( potionMenuInput == 3 ) {
          h.usePotion();
          System.out.println( e.attack( h ) );
        }
      } else {
        int menuInput = CheckInput.getIntRange( 1, 2 );
        if ( menuInput == 1 ) {
          boolean fightResult = fight( h, e );
          if ( !fightResult ){
            int ranGold = (int)( ( Math.random()*25 )*h.getLevel() )+1;
            h.collectGold( ranGold );
            EnemyAlive = false;
          }
        }
        if (menuInput == 2) {
          int ranDirec = (int)( Math.random()*4 )+1;
          switch( ranDirec ){
            case 1:
              char result = h.goNorth();
              if ( result == 'x' ){
                h.goSouth();
              }
              break;
            case 2:
              result = h.goSouth();
              if ( result == 'x' ){
                h.goNorth();
              }
              break;
            case 3:
              result = h.goEast();
              if ( result == 'x' ){
                h.goWest();
              }
              break;
            case 4:
              result = h.goWest();
              if ( result == 'x' ){
                h.goEast();
              }
              break;
          }
          return EnemyAlive;
        }
      }
    }
    return EnemyAlive;
  }

  /**
  *Fight where a single round of combat happens
  *@param the Hero controlled by the player
  *@param the Enemy which the player is fighting
  *@return Whether the enemy is still alive
  */
  public static boolean fight( Hero h, Enemy e ) {
    System.out.println( h.getAttackMenu() );
    int attackType = h.getNumAttackMenuItems();
    System.out.println( h.getSubAttackMenu( attackType ) );     
    int subAttackType = h.getNumSubAttackMenuItems( attackType );
    System.out.println( h.attack( e,attackType,subAttackType ) );
    if ( e.getHp() > 0 ) {
      System.out.println( e.attack( h ) );
      return true;
    }
    return false;
  }

  /**
  *Store function, where the player can buy items
  *@param the hero visiting the shop
  */
  public static void store( Hero h ) {
    System.out.println( "Welcome to the store! What would you like to buy?" );
    System.out.println( "1. Health Potion - 25g\n2. Key - 50g\n3. Nothing, just browsing..." );
    int storeInput = CheckInput.getIntRange( 1, 3 );
    if ( storeInput == 1 ) {
      if ( h.spendGold( 25 ) ) {
        h.pickUpPotion();
        System.out.println( "Thank you for shopping here!" );
      } else {
        System.out.println( "You don't have enough money!" );
      }
    }
    if ( storeInput == 2 ) {
      if ( h.spendGold( 50 ) ) {
        h.pickUpKey();
        System.out.println( "Thank you for shopping here!" );
      } else {
        System.out.println( "You don't have enough money!" );
      }
    }
    if ( storeInput == 3 ) {
      System.out.println( "If you're gonna come here you might as well buy something..." );
    }
  }

  /**
  *The main menu where the hero decides which direction to go and if they continue the game
  *@param The hero the player is controlling
  *@return the choice the player has made for movement
  */
  public static int mainMenu( Hero h ) {
    System.out.println( "1. Go North\n2. Go South\n3. Go East\n4. Go West\n5. Quit" );
    int menuInput = CheckInput.getIntRange( 1, 5 );
    return menuInput;
  }
}
