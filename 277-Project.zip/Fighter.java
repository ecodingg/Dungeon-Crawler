/**
*The fighter interface, used for the player and enemies
*/
public interface Fighter {
  static final String FIGHTER_MENU = "1. Sword\n2. Axe";
  static final int NUM_FIGHTER_MENU_ITEMS = 2;
  String sword( Entity e );
  String axe( Entity e );
}
