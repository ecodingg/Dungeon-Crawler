import java.awt.*;
import java.io.*;
import java.util.*;

public class Map {
  private char[][] map;
  private boolean[][] revealed;
  private static Map instance = null;

  /**
  *Constructor for Map
  */
  private Map() {
    map = new char[5][5];
    revealed = new boolean[5][5];
    //loadMap(1);
    }

  /**
  *Returns the current instance of the map, or generates a new one if there isn't one
  *@return the current instance of the map
  */
  public static Map getInstance() {
    if ( instance == null ) {
      instance = new Map();
    }
    return instance;
  }

  /**
  *Loads a map file based on the integer sent in
  *@param the file number of the map to be loaded
  */
  public void loadMap( int mapNum ) {
    Scanner scan;
    switch ( mapNum ) {
    case 1:
      File file1 = new File( "Map1.txt" );
      try {
        scan = new Scanner( file1 );
        for ( int i = 0; i < 5; i++ ) {
          for ( int j = 0; j < 5; j++ ) {
            map[i][j] = scan.next().charAt( 0 );
            // System.out.println( s );
          }
        }
        scan.close();
      }
      catch ( FileNotFoundException e ){}
      break;
    case 2:
      File file2 = new File( "Map2.txt" );
      try {
        scan = new Scanner( file2 );
        for ( int i = 0; i < 5; i++ ) {
          for ( int j = 0; j < 5; j++ ) {
            map[i][j] = scan.next().charAt( 0 );
            // System.out.println( s );
          }
        }
        scan.close();
      }
      catch ( FileNotFoundException e ){}
      break;
    case 3:
      File file3 = new File( "Map3.txt" );
      try {
        scan = new Scanner( file3 );
        for ( int i = 0; i < 5; i++ ) {
          for ( int j = 0; j < 5; j++ ) {
            map[i][j] = scan.next().charAt( 0 );
            // System.out.println( s );
          }
        }
        scan.close();
      }
      catch ( FileNotFoundException e ){}
      break;
    }
    for ( int i = 0; i < 5; i++ ) {
      for ( int j = 0; j < 5; j++ ) {
        revealed[i][j] = false;
        if ( map[i][j] == 's' ) {
          revealed[i][j] = true;
        }
      }
    }
  }

  /**
  *Return the room at the given location
  *@param the location on the map you want the room for
  *@return the type of room it is
  */
  public char getCharAtLoc( Point P ) {
    return map[(int) P.getY()][(int) P.getX()];
  }

  /**
  *Find the starting location and return it as a point
  *@return the starting location
  */
  public Point findStart() {
    for ( int i = 0; i < map.length; i++ ) {
      for ( int j = 0; j < map[i].length; j++ ) {
        if ( map[i][j] == 's' ) {
          Point p = new Point( j, i );
          return p;
        }
      }
    }
    //default return (should never occur)
    return new Point();
  }

  /**
  *Reveal a specific location on the map
  *@param the location to be revealed
  */
  public void reveal( Point p ) {
    revealed[(int) p.getY()][(int) p.getX()] = true;
  }

  /**
  *Removes the selected location's room, setting it to no room 'n'
  *@param the location of the room to be removed
  */
  public void removeCharAtLoc( Point p ) {
    map[(int)p.getY()][(int)p.getX()] = 'n';
  }

  /**
  *Convert the map to a string for display purposes
  *@param the location of the hero
  *@return A 5-lined string displaying all revealed rooms and the hero
  */
  public String mapToString( Point p ) {
    String mapString = "";
    for ( int i = 0; i < 5; i++ ) {
      for ( int j = 0; j < 5; j++ ) {
        if ( i == p.getY() && j == p.getX() ) {
          mapString += '*';
        } else if ( revealed[i][j] ) {
          mapString += map[i][j];
        } else {
          mapString += 'x';
        }
      }
      mapString += '\n';
    }
    return mapString;
  }
}
