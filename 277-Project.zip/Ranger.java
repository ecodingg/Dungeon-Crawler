import java.util.*;
/**
*One of the enemy architypes, implements the Archer interface
*/
public class Ranger extends Enemy implements Archer{
  /**
  *The Ranger constructor
  *@param The name of the Entity
  *@param The maximum health of the Entity
  *@return The super constructor of the Entity
  */
  public Ranger( String name, int maxHP ){
    super( name, maxHP );
  }

  /**
  *The arrow attack
  *Returns the string for the attack
  *@param The entity using the Arrow Attack
  *@return A string response of the arrow attack
  */
  @Override
  public String arrow( Entity e ) {
    int attackDamage = (int)( Math.random()*3+1 );
    e.takeDamage( attackDamage );
    return super.getName() + " shoots " + e.getName() + " with an arrow for " + attackDamage;
  }

  /**
  *The fire arrow attack
  *Returns the string for the attack
  *@param The entity using the fire arrow attack
  *@return A string response of the fire arrow attack
  */
  @Override
  public String fireArrow( Entity e ) {
    int attackDamage = (int)( Math.random()*5 +1 );
    e.takeDamage(attackDamage);
    return super.getName() + " shoots " + e.getName() + " with a fire arrow for " + attackDamage;
  }

  /**
  *The attack function
  *ranAttack randomly selects a number between 1 and 2 and then the function determines which attack to do based on the number
  *@param The hero that the player uses  
  *@return The attack chosen
  */
  @Override
  public String attack( Hero h ) {
    int ranAttack = (int)( Math.random()*2+1 );
    if ( ranAttack == 1 ){
      return this.arrow( h );
    }
    if ( ranAttack == 2 ){
      return this.fireArrow( h );
    }
    return null;
  }
}
