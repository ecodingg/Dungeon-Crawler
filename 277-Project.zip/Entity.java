public abstract class Entity {
  private String name;
  private int hp;
  private int maxHp;

  /**
  *Constructs an entity
  */
  public Entity( String n, int mHp )  {
    name = n;
    maxHp = mHp;
    hp = mHp;
  }
  /**
  *returns the name of the entity
  *@return name of entitiy
  */
  String getName() {
    return name;
  }
  /**
  *returns the current health of the entity
  *@return entity health
  */
  int getHp() {
    return hp;
  }
  /**
  *Heals the entity to max hp
  */
  void heal() {
    hp = maxHp;
  }
  /**
  * subtracts the paramater from the health and check if health is lover than zero and if it is, set health to 0.
  *@param d is damage given
  */
  void takeDamage( int d ) {
    hp = hp - d;
    if ( hp < 0 ) {
      hp = 0;
    }
  }
  /**
  *Outputs the data about the object as a string
  *@return The string about the object
  */
  @Override
  public String toString() {
    return name + "\n" + hp + "/" + maxHp;
  }
}
