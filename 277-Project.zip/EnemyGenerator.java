import java.util.*;
import java.io.*;
public class EnemyGenerator{
  private HashMap<String, Integer> enemies;

  /**
  *The EnemyGenerator constructor
  *@return an EnemyGenerator Object
  */
  public EnemyGenerator(){
    enemies = new HashMap<String, Integer>();
    try {
      File enemyFile = new File( "Enemies.txt" );
      Scanner scan = new Scanner( enemyFile );
      while ( scan.hasNext() ) {
        String name = scan.nextLine();
        int index = name.indexOf( "," );
        int hp = Integer.parseInt( name.substring( index+1 ) );
        name = name.substring( 0, index );
        enemies.put( name, hp );
      }
      scan.close();
    } catch ( Exception e ) {
      e.printStackTrace();
    }
  }

  /**
  *A function that creates an enemy scaled to the player
  *@param the level of the player
  *@return An Enemy appropriate to the player
  */
  public Enemy generateEnemy( int level ){
    /*Find a random name from the HashMap
    This would probably be better with a different map implementation, like a linked list of pairs
    And to just use the .shuffle() method on the map
    While in theory it makes sense since the hash is already "Random"
    Java doesn't allow us to directly access the hash's elements without the key
    Or to index the elements in the key set either
    But I might have missed an easier/better implementation
    I felt this was the "Best" implementation I could come up with*/
    Object[] nameArray = enemies.keySet().toArray();
    int enemyIndex = (int)( Math.random() * nameArray.length );
    String name = nameArray[enemyIndex].toString();
    int hp = enemies.get( name ) * level;
    Enemy baddie = null;
    switch ( (int)( Math.random() * 3 ) ){
      case 0:
        baddie = new Ranger( name, hp );
        break;
      case 1:
        baddie = new Warrior( name, hp );
        break;
      case 2:
        baddie = new Wizard( name, hp );
        break;
    }
    return baddie;
  }
}
