/**
*The archer interface, used for the player and enemies
*/
public interface Archer {
  static final String ARCHER_MENU = "1. Arrow\n2. Fire Arrow";
  static final int NUM_ARCHER_MENU_ITEMS = 2;
  String arrow( Entity e );
  String fireArrow( Entity e );
}
